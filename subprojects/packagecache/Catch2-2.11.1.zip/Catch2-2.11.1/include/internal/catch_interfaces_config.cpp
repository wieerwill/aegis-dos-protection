#include "catch_interfaces_config.h"

namespace Catch {
    IConfig::~IConfig() = default;
}
